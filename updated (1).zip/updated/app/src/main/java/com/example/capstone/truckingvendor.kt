package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class truckingvendor : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_truckingvendor)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Receive truck and customer data from intent
        val extras = intent.extras
        if (extras != null) {
            // Truck details
            val vehicleId = extras.getString("vehicleId") ?: "N/A"
            val vendor = extras.getString("vendor") ?: "N/A"
            val type = extras.getString("type") ?: "N/A"
            val driver = extras.getString("driverName") ?: "N/A"
            val availability = extras.getBoolean("isAvailable")

            // Update truck details in UI
            findViewById<TextView>(R.id.truck_info).text = "Truck: $type ($vehicleId)"
            findViewById<TextView>(R.id.route_info).text = "Vendor: $vendor"
            findViewById<TextView>(R.id.driver_info).text = "Driver: $driver"
            findViewById<TextView>(R.id.availability_status).text =
                if (availability) "Available" else "Not Available"

            // Customer details
            val fullName = extras.getString("customerName", "N/A")
            val items = extras.getString("items", "N/A")
            val pickup = extras.getString("pickup", "N/A")
            val dropoff = extras.getString("dropoff", "N/A")
            val preferredDate = extras.getString("dateTime", "N/A")

            // Update customer details in UI
            findViewById<TextView>(R.id.customerNameValue).text = fullName
            findViewById<TextView>(R.id.itemsValue).text = items
            findViewById<TextView>(R.id.pickupValue).text = pickup
            findViewById<TextView>(R.id.dropoffValue).text = dropoff
            findViewById<TextView>(R.id.dateTimeValue).text = preferredDate
        }

        // Spinner for status selection
        val statusSpinner = findViewById<Spinner>(R.id.statusSpinner)
        statusSpinner.setSelection(0) // Optional: Set default selection to "Pending"

        // Listener for status spinner
        statusSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val status = parent?.getItemAtPosition(position).toString()
                // Show a Toast notification for the selected status
                Toast.makeText(this@truckingvendor, "Status: $status", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing when no item is selected
            }
        }

        // Back button functionality
        findViewById<Button>(R.id.backButton).setOnClickListener {
            // Navigate back to Fleet
            val intent = Intent(this, Fleet::class.java)
            startActivity(intent)
            finish() // Remove truckingvendor from the back stack
        }

        // Heatmap button functionality
        findViewById<Button>(R.id.heatmapButton).setOnClickListener {
            // Navigate to Heatmap activity
            val intent = Intent(this, heatmap::class.java)
            startActivity(intent)
        }
    }

    // Override the back button behavior to navigate back to Fleet
    override fun onBackPressed() {
        val intent = Intent(this, Fleet::class.java)
        startActivity(intent)
        finish() // Close truckingvendor activity
    }
}
